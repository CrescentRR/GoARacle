GoARacle by CrescentRR

This is a program made to read KH2FM seed files (pnach) and give you hints for your runs.

How to use:

-Press the "Select Seed" button, then path to the location of your seed.  Select your seed (pnach) file and confirm your choice.

-When you collect a report, click on the respective report to get a hint.  

For more information about what each pool entails, press the About button to see what items are in the pools.


The best world in the seed is listed under Report 1, continuting to the 13th best world under Report 13.


If you have any issues, contact CrescentRR on Discord.